import os
import json
import lambda_download
import lambda_upload

def lambda_handler (event, context):
    # TODO implement
    environ = os.environ.get ("ENVIRON")
    if environ == "DEV":
        os.environ.setdefault ("AWS_DEFAULT", "udemy-github-profile")
    file = "2021-01-29-1.json.gz"
    download = lambda_download.lambda_downloader (file)
    uploader = lambda_upload.lambda_uploader ("s3")
    #print ("Just made the uploader")
    result = lambda_upload.lambda_upload (uploader, os.environ.get ("BUCKET_NAME"), file, download.content)
    #print ("Just produced the result from uploading")
    '''
    return {
        'statusCode': response.status_code,#200,
        'body': json.dumps ("Download status code")#json.dumps('Hello from Lambda! (In the lambda project)')
    }
    '''
    print (result)
    return result
